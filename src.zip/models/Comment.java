package models;

public class Comment {
}
