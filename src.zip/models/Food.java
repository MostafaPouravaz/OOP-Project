package models;

import java.time.LocalDateTime;
import java.util.ArrayList;
//edit setter getter
//comment rating (rating amade nist)
public class Food {
    private ArrayList<Rating> ratings = new ArrayList<>();
    private int finalRate;
    private String name;
    private final static ArrayList<Food> allFoods = new ArrayList<>();
    private int ID;
    private static int IDCounter=0;
    private int price;
    private int ID_restaurant;
    LocalDateTime startTime;
    int period;
    int foodTypeID;
    private int discount;
    private boolean active = false;
    private boolean isDiscounted = false;
    public void discounter (int timePeriod){
        this.startTime = LocalDateTime.now();
        this.period = timePeriod;
        this.isDiscounted = true;
    }
    public boolean discountActive(){
        if (!isDiscounted)
            return false;
        return LocalDateTime.now().isBefore(startTime.plusSeconds(this.period));
    }//for identifying that had discount or no or time is spent.

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getPrice() {
        if (discountActive())
            return price*(100-getDiscount())/100;
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getID_restaurant() {
        return ID_restaurant;
    }

    public void setID_restaurant(int ID_restaurant) {
        this.ID_restaurant = ID_restaurant;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public boolean isActive() {
        return active;
    }

    public int getFoodTypeID() {
        return foodTypeID;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public int getFinalRate() {
        finalRate = 0;
        for (Rating rating : ratings) finalRate += rating.getRate();
        return finalRate;
    }
    public void addRate(int customerID, int rate){
        ratings.add(new Rating(ID, customerID, rate));

    }

    public Food(String name, int price, int ID_restaurant, int foodTypeID) {
        this.name = name;
        this.price = price;
        this.ID_restaurant = ID_restaurant;
        this.foodTypeID = foodTypeID;
        this.active =true;
        this.ID = ++IDCounter;
        Food.allFoods.add(this);
    }
}
