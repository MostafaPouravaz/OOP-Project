package enums;

public enum FoodType {
    FASTFOOD,
    IRANIANFOOD,
    SEAFOOD,
    APPETIZER,
    OTHER;


    public static FoodType getFoodTypeFromInt(int foodTypeID) {
        return switch (foodTypeID) {
            case 0 -> FASTFOOD;
            case 1 -> IRANIANFOOD;
            case 2 -> SEAFOOD;
            case 3 -> APPETIZER;
            case 4 -> OTHER;
            default -> null;
        };
    }
}
