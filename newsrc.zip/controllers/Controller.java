package controllers;

public abstract class Controller {
}
