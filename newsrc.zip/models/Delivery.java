package models;

import java.io.IOException;

public class Delivery {
//    String filename;
//    int source;//-1
//    int destination;//-1
//    Map map = new Map(filename);
//    map.floydWarshall();
//    System.out.println("Shortest distance between nodes " + (source + 1) + " and " + (destination + 1) + ": " + map.getShortestDistance(source, destination));
//    System.out.println("Shortest path between nodes " + (source + 1) + " and " + (destination + 1) + ": " + map.getShortestPath(source, destination));
//
//
}
