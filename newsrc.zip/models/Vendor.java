package models;

public class Vendor extends User{

    public Vendor(String username, String password) {
        super(username, password);
    }

}
